const mongoose = require('mongoose');

// Reserved for the fraud detection model — not written to yet.
// Intended usage: one entry per fraud check run against a listing.
const fraudLogSchema = new mongoose.Schema(
  {
    product: { type: mongoose.Schema.Types.ObjectId, ref: 'Product', required: true },
    seller: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    score: { type: Number, required: true },
    flags: [{ type: String }],
    decision: {
      type: String,
      enum: ['allow', 'flag_for_review', 'block'],
      required: true,
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model('FraudLog', fraudLogSchema);
