const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    email: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
      match: [/^\S+@\S+\.\S+$/, 'Please provide a valid email'],
    },
    password: { type: String, required: true, minlength: 6, select: false },
    campus: { type: String, trim: true },
    phone: { type: String, trim: true },
    role: { type: String, enum: ['student', 'admin'], default: 'student' },

    // --- Reserved for the fraud detection model (not populated yet) ---
    accountStatus: {
      type: String,
      enum: ['active', 'flagged', 'suspended'],
      default: 'active',
    },
    trustScore: { type: Number, default: 50, min: 0, max: 100 },
    isVerified: { type: Boolean, default: false },
    listingCount24h: { type: Number, default: 0 },
    lastListingAt: { type: Date },
    reportCount: { type: Number, default: 0 },
  },
  { timestamps: true }
);

userSchema.pre('save', async function hashPassword(next) {
  if (!this.isModified('password')) return next();
  const salt = await bcrypt.genSalt(10);
  this.password = await bcrypt.hash(this.password, salt);
  next();
});

userSchema.methods.comparePassword = function comparePassword(candidate) {
  return bcrypt.compare(candidate, this.password);
};

module.exports = mongoose.model('User', userSchema);
