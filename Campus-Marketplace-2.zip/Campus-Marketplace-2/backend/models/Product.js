const mongoose = require('mongoose');

const CATEGORIES = [
  'textbooks',
  'electronics',
  'furniture',
  'hostel-essentials',
  'sports',
  'clothing',
  'stationery',
  'other',
];

const CONDITIONS = ['new', 'like-new', 'good', 'fair', 'poor'];

const productSchema = new mongoose.Schema(
  {
    seller: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    title: { type: String, required: true, trim: true, maxlength: 120 },
    description: { type: String, required: true, maxlength: 2000 },
    category: { type: String, enum: CATEGORIES, required: true },
    condition: { type: String, enum: CONDITIONS, required: true },

    price: { type: Number, required: true, min: 0 },
    ageInMonths: { type: Number, default: 0, min: 0 },

    images: [{ type: String }],

    status: {
      type: String,
      enum: ['active', 'sold', 'removed', 'under_review'],
      default: 'active',
    },

    views: { type: Number, default: 0 },
    savedCount: { type: Number, default: 0 },

    // --- Reserved for the price prediction model (not populated yet) ---
    suggestedPrice: { type: Number },

    // --- Reserved for the fraud detection model (not populated yet) ---
    imageHashes: [{ type: String }],
    fraudScore: { type: Number, default: 0, min: 0, max: 100 },
    fraudFlags: [{ type: String }],
    isFlagged: { type: Boolean, default: false },
  },
  { timestamps: true }
);

productSchema.index({ category: 1, condition: 1 });
productSchema.index({ title: 'text', description: 'text' });

productSchema.statics.CATEGORIES = CATEGORIES;
productSchema.statics.CONDITIONS = CONDITIONS;

module.exports = mongoose.model('Product', productSchema);
