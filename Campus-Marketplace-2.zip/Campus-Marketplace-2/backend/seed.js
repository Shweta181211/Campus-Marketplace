require('dotenv').config();
const mongoose = require('mongoose');
const connectDB = require('./config/db');
const User = require('./models/User');
const Product = require('./models/Product');

const sampleUsers = [
  { name: 'Aarav Sharma', email: 'aarav@campus.edu', password: 'password123', campus: 'North Campus' },
  { name: 'Priya Singh', email: 'priya@campus.edu', password: 'password123', campus: 'North Campus' },
  { name: 'Rohan Gupta', email: 'rohan@campus.edu', password: 'password123', campus: 'South Campus' },
];

const categories = ['textbooks', 'electronics', 'furniture', 'hostel-essentials', 'sports'];
const conditions = ['new', 'like-new', 'good', 'fair', 'poor'];
const basePrices = { textbooks: 400, electronics: 3500, furniture: 1800, 'hostel-essentials': 600, sports: 900 };

function randomItem(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

async function seed() {
  await connectDB();

  await User.deleteMany({});
  await Product.deleteMany({});

  const users = await User.create(sampleUsers);

  const products = [];
  for (let i = 0; i < 20; i += 1) {
    const category = randomItem(categories);
    const condition = randomItem(conditions);
    const ageInMonths = Math.floor(Math.random() * 24);
    const price = Math.round(basePrices[category] * (0.6 + Math.random() * 0.5));

    products.push({
      seller: randomItem(users)._id,
      title: `${category} item #${i + 1}`,
      description: `A ${condition} condition ${category} item, used for ${ageInMonths} months.`,
      category,
      condition,
      price,
      ageInMonths,
      status: 'active',
    });
  }

  await Product.insertMany(products);
  console.log(`Seeded ${users.length} users and ${products.length} products.`);
  await mongoose.disconnect();
}

seed().catch((err) => {
  console.error(err);
  process.exit(1);
});
