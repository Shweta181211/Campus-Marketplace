const asyncHandler = require('express-async-handler');
const Product = require('../models/Product');
const { predictPrice } = require('../services/pricePredictionService');

// @route POST /api/price/estimate
// body: { category, condition, ageInMonths }
// NOTE: pricePredictionService.predictPrice() is a stub until the AI price
// prediction model is implemented — this route will return 501 until then.
const estimatePrice = asyncHandler(async (req, res) => {
  const { category, condition, ageInMonths } = req.body;

  if (!category || !condition) {
    res.status(400);
    throw new Error('category and condition are required');
  }
  if (!Product.CATEGORIES.includes(category)) {
    res.status(400);
    throw new Error(`Invalid category. Must be one of: ${Product.CATEGORIES.join(', ')}`);
  }
  if (!Product.CONDITIONS.includes(condition)) {
    res.status(400);
    throw new Error(`Invalid condition. Must be one of: ${Product.CONDITIONS.join(', ')}`);
  }

  try {
    const result = await predictPrice({
      category,
      condition,
      ageInMonths: Number(ageInMonths) || 0,
    });
    res.json(result);
  } catch (err) {
    res.status(501);
    throw new Error(`Price prediction not available yet: ${err.message}`);
  }
});

module.exports = { estimatePrice };
