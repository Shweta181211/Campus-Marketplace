const asyncHandler = require('express-async-handler');
const Product = require('../models/Product');
const FraudLog = require('../models/FraudLog');
const User = require('../models/User');
const { evaluateListing } = require('../services/fraudDetectionService');

// @route POST /api/fraud/evaluate/:productId
// Runs the fraud check against an existing listing. NOTE:
// fraudDetectionService.evaluateListing() is a stub until the AI fraud
// detection model is implemented — this route will return 501 until then.
const evaluateProduct = asyncHandler(async (req, res) => {
  const product = await Product.findById(req.params.productId);
  if (!product) {
    res.status(404);
    throw new Error('Product not found');
  }
  const seller = await User.findById(product.seller);

  try {
    const result = await evaluateListing(product, seller);

    product.fraudScore = result.score;
    product.fraudFlags = result.flags;
    product.isFlagged = result.decision !== 'allow';
    await product.save();

    await FraudLog.create({
      product: product._id,
      seller: seller._id,
      score: result.score,
      flags: result.flags,
      decision: result.decision,
    });

    res.json(result);
  } catch (err) {
    res.status(501);
    throw new Error(`Fraud detection not available yet: ${err.message}`);
  }
});

// @route GET /api/fraud/flagged
const getFlaggedListings = asyncHandler(async (req, res) => {
  const products = await Product.find({ isFlagged: true })
    .populate('seller', 'name email trustScore accountStatus')
    .sort('-createdAt')
    .limit(100);
  res.json(products);
});

// @route GET /api/fraud/logs/:productId
const getFraudLogs = asyncHandler(async (req, res) => {
  const logs = await FraudLog.find({ product: req.params.productId }).sort('-createdAt');
  res.json(logs);
});

// @route POST /api/fraud/review/:productId
// body: { action: 'approve' | 'remove' | 'suspend_seller' }
const reviewListing = asyncHandler(async (req, res) => {
  const { action } = req.body;
  const product = await Product.findById(req.params.productId);
  if (!product) {
    res.status(404);
    throw new Error('Product not found');
  }

  if (action === 'approve') {
    product.isFlagged = false;
    product.status = 'active';
    await product.save();
  } else if (action === 'remove') {
    product.status = 'removed';
    await product.save();
  } else if (action === 'suspend_seller') {
    product.status = 'removed';
    await product.save();
    await User.findByIdAndUpdate(product.seller, {
      accountStatus: 'suspended',
      $inc: { reportCount: 1 },
    });
  } else {
    res.status(400);
    throw new Error('action must be one of: approve, remove, suspend_seller');
  }

  res.json({ message: `Action '${action}' applied`, product });
});

module.exports = { evaluateProduct, getFlaggedListings, getFraudLogs, reviewListing };
