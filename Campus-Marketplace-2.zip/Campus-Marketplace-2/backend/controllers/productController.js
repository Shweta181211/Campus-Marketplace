const asyncHandler = require('express-async-handler');
const Product = require('../models/Product');

// @route POST /api/products
const createProduct = asyncHandler(async (req, res) => {
  const { title, description, category, condition, price, ageInMonths, images } = req.body;

  if (!title || !description || !category || !condition || price == null) {
    res.status(400);
    throw new Error('title, description, category, condition and price are required');
  }

  const product = await Product.create({
    seller: req.user._id,
    title,
    description,
    category,
    condition,
    price,
    ageInMonths: ageInMonths || 0,
    images: images || [],
  });

  // NOTE: Price prediction and fraud scoring are not wired in yet.
  // Once available, call them here (or via a post-save hook) and persist
  // the results onto `product.suggestedPrice` / `product.fraudScore` etc.

  res.status(201).json(product);
});

// @route GET /api/products
const getProducts = asyncHandler(async (req, res) => {
  const { category, condition, minPrice, maxPrice, search, page = 1, limit = 20 } = req.query;

  const filter = { status: 'active' };
  if (category) filter.category = category;
  if (condition) filter.condition = condition;
  if (minPrice || maxPrice) {
    filter.price = {};
    if (minPrice) filter.price.$gte = Number(minPrice);
    if (maxPrice) filter.price.$lte = Number(maxPrice);
  }
  if (search) filter.$text = { $search: search };

  const skip = (Number(page) - 1) * Number(limit);
  const [products, total] = await Promise.all([
    Product.find(filter)
      .populate('seller', 'name campus')
      .sort('-createdAt')
      .skip(skip)
      .limit(Number(limit)),
    Product.countDocuments(filter),
  ]);

  res.json({ products, total, page: Number(page), pages: Math.ceil(total / limit) });
});

// @route GET /api/products/:id
const getProductById = asyncHandler(async (req, res) => {
  const product = await Product.findById(req.params.id).populate('seller', 'name campus phone');
  if (!product) {
    res.status(404);
    throw new Error('Product not found');
  }
  product.views += 1;
  await product.save();
  res.json(product);
});

// @route PUT /api/products/:id
const updateProduct = asyncHandler(async (req, res) => {
  const product = await Product.findById(req.params.id);
  if (!product) {
    res.status(404);
    throw new Error('Product not found');
  }
  if (String(product.seller) !== String(req.user._id)) {
    res.status(403);
    throw new Error('Not authorized to edit this listing');
  }

  const updatable = ['title', 'description', 'category', 'condition', 'price', 'ageInMonths', 'images', 'status'];
  updatable.forEach((field) => {
    if (req.body[field] !== undefined) product[field] = req.body[field];
  });

  await product.save();
  res.json(product);
});

// @route DELETE /api/products/:id
const deleteProduct = asyncHandler(async (req, res) => {
  const product = await Product.findById(req.params.id);
  if (!product) {
    res.status(404);
    throw new Error('Product not found');
  }
  if (String(product.seller) !== String(req.user._id) && req.user.role !== 'admin') {
    res.status(403);
    throw new Error('Not authorized to delete this listing');
  }
  await product.deleteOne();
  res.json({ message: 'Listing removed' });
});

module.exports = {
  createProduct,
  getProducts,
  getProductById,
  updateProduct,
  deleteProduct,
};
