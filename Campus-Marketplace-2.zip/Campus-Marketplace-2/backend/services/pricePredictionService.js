/**
 * Price Prediction Service — STUB
 * -----------------------------------------------------------------------
 * Reserved for the teammate implementing the AI price prediction model.
 *
 * Expected interface:
 *
 *   predictPrice({ category, condition, ageInMonths }) -> Promise<{
 *     suggestedPrice: number,
 *     confidence?: string,
 *     range?: { low: number, high: number },
 *   }>
 *
 * `category` and `condition` will match Product.CATEGORIES / Product.CONDITIONS
 * (see models/Product.js). `ageInMonths` is a non-negative number.
 *
 * Once implemented, wire this into:
 *   - controllers/priceController.js (already calls this function)
 *   - controllers/productController.js's createProduct, to persist
 *     `suggestedPrice` on the Product document if desired
 * -----------------------------------------------------------------------
 */

async function predictPrice({ category, condition, ageInMonths }) {
  throw new Error('predictPrice() is not implemented yet');
}

module.exports = { predictPrice };
