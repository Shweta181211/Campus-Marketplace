/**
 * Fraud Detection Service — STUB
 * -----------------------------------------------------------------------
 * Reserved for the teammate implementing the AI fraud detection model.
 *
 * Expected interface:
 *
 *   evaluateListing(product, seller) -> Promise<{
 *     score: number,           // 0-100
 *     flags: string[],         // e.g. ['price_far_below_market', 'new_account']
 *     decision: 'allow' | 'flag_for_review' | 'block',
 *   }>
 *
 * `product` is a Product document/object (see models/Product.js — includes
 * price, category, condition, images, etc). `seller` is the User document
 * who created the listing (see models/User.js — includes accountStatus,
 * trustScore, listingCount24h, reportCount, etc, reserved for this model).
 *
 * Once implemented, wire this into:
 *   - controllers/fraudController.js (already calls this function)
 *   - controllers/productController.js's createProduct, to score new
 *     listings and persist `fraudScore` / `fraudFlags` / `isFlagged`
 *   - models/FraudLog.js can be used to keep an audit trail of each check
 * -----------------------------------------------------------------------
 */

async function evaluateListing(product, seller) {
  throw new Error('evaluateListing() is not implemented yet');
}

module.exports = { evaluateListing };
