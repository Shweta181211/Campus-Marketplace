const express = require('express');
const {
  evaluateProduct,
  getFlaggedListings,
  getFraudLogs,
  reviewListing,
} = require('../controllers/fraudController');
const { protect, adminOnly } = require('../middleware/authMiddleware');

const router = express.Router();

// Returns 501 until fraudDetectionService.evaluateListing() is implemented.
router.post('/evaluate/:productId', protect, evaluateProduct);

router.get('/flagged', protect, adminOnly, getFlaggedListings);
router.get('/logs/:productId', protect, adminOnly, getFraudLogs);
router.post('/review/:productId', protect, adminOnly, reviewListing);

module.exports = router;
