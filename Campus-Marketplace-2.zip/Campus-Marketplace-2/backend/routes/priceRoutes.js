const express = require('express');
const { estimatePrice } = require('../controllers/priceController');

const router = express.Router();

// Returns 501 until pricePredictionService.predictPrice() is implemented.
router.post('/estimate', estimatePrice);

module.exports = router;
