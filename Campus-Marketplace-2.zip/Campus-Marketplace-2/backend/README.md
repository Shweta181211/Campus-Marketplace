# Campus Marketplace — Backend

Node.js/Express + MongoDB backend for Campus Marketplace: auth, listings CRUD,
and database wiring. **Price prediction and fraud detection are stubbed** —
see [AI model handoff](#ai-model-handoff) below for what your teammate needs to fill in.

## Setup

```bash
cd backend
npm install
cp .env.example .env   # set MONGO_URI and JWT_SECRET
npm run seed             # optional: sample users + listings
npm run dev              # http://localhost:5000
```

Requires MongoDB — local (`mongodb://localhost:27017/campus_marketplace`) or a free
[MongoDB Atlas](https://www.mongodb.com/atlas) cluster.

## Project structure

```
backend/
├── config/db.js                    MongoDB connection
├── models/                         User, Product, FraudLog schemas
├── controllers/
│   ├── authController.js           register / login / profile
│   ├── productController.js        listing CRUD (fully working)
│   ├── priceController.js          calls pricePredictionService (stub)
│   └── fraudController.js          calls fraudDetectionService (stub)
├── services/
│   ├── pricePredictionService.js   STUB — see AI model handoff
│   └── fraudDetectionService.js    STUB — see AI model handoff
├── middleware/                     authMiddleware.js, errorMiddleware.js
├── routes/                         authRoutes, productRoutes, priceRoutes, fraudRoutes
├── utils/jwt.js
├── seed.js
├── server.js
└── package.json
```

## API overview

### Auth
| Method | Route | Description |
|---|---|---|
| POST | `/api/auth/register` | Create account |
| POST | `/api/auth/login` | Log in, returns JWT |
| GET | `/api/auth/me` | Current user (auth required) |

### Products (fully working)
| Method | Route | Description |
|---|---|---|
| GET | `/api/products` | List/search/filter listings |
| POST | `/api/products` | Create a listing (auth required) |
| GET | `/api/products/:id` | Get one listing |
| PUT | `/api/products/:id` | Update your own listing (auth required) |
| DELETE | `/api/products/:id` | Delete your own listing (auth required) |

### Price / Fraud (stubbed — currently return `501 Not Implemented`)
| Method | Route | Description |
|---|---|---|
| POST | `/api/price/estimate` | Get a suggested price for `{ category, condition, ageInMonths }` |
| POST | `/api/fraud/evaluate/:productId` | Run a fraud check on a listing (auth required) |
| GET | `/api/fraud/flagged` | List flagged listings (admin only) |
| GET | `/api/fraud/logs/:productId` | Fraud-check history for a listing (admin only) |
| POST | `/api/fraud/review/:productId` | `{ action: 'approve' \| 'remove' \| 'suspend_seller' }` (admin only) |

To make a user an admin, set `role: 'admin'` on their document in MongoDB.

## AI model handoff

Two files are ready for the AI implementation and nothing else needs to change
around them — routes, controllers, and the DB schema already expect these exact
shapes:

**`services/pricePredictionService.js`**
```js
predictPrice({ category, condition, ageInMonths }) -> Promise<{
  suggestedPrice: number,
  confidence?: string,
  range?: { low: number, high: number },
}>
```

**`services/fraudDetectionService.js`**
```js
evaluateListing(product, seller) -> Promise<{
  score: number,        // 0-100
  flags: string[],
  decision: 'allow' | 'flag_for_review' | 'block',
}>
```

`product` and `seller` are Mongoose documents from `models/Product.js` and
`models/User.js` — both already have fields reserved for this (`suggestedPrice`,
`fraudScore`, `fraudFlags`, `isFlagged` on Product; `trustScore`, `accountStatus`,
`listingCount24h`, `reportCount` on User). `models/FraudLog.js` is ready to store
an audit trail of each fraud check. Once both functions are implemented, the
`/api/price/estimate` and `/api/fraud/evaluate/:productId` routes will start
returning real results instead of `501`.
