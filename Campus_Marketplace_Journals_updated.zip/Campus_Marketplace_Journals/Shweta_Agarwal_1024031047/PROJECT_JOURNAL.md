# Campus Marketplace — Project Journal

**Student:** Shweta Agarwal (1024031047)
**Group:** 3C73, BE Third Year, CSE
**Course:** UCS503 - Software Engineering
**Project:** Campus Marketplace (Buy / Borrow / Sell / Lend web app)
**Stack:** React (Vite) frontend · Express.js API · MongoDB (Mongoose) · Python/FastAPI ML services
**My focus:** Frontend, frontend-backend integration, demo data, UI for the AI / payment / location features, and documentation.

---

## 1. Project goal

Build a campus marketplace where verified students can browse listings, sell or lend items, chat, transact, manage a profile with trust scores, and (for admins) review a moderation queue. The UI existed first as a frontend-only prototype; the project then became a full-stack system. My part covered connecting the React frontend to the backend cleanly, making every screen work with real data, surfacing the AI, payment and location features in the interface, and making sure the app looked and worked properly for demos, not just in theory.

---

## 2. Problems I worked on and how they were overcome

### Problem 1 — Frontend icons could not be stored in MongoDB

**What happened:**
Listings in the UI used Lucide React icon **components** (`BookOpen`, `Bike`, etc.). Those cannot be saved in MongoDB as functions.

**How it was overcome:**
- Stored a string field `iconKey` (e.g. `"books"`, `"electronics"`) in the Listing schema.
- Added `hydrateListing()` on the frontend to map `iconKey` to a Lucide component before rendering cards and details.

---

### Problem 2 — CORS / API URL mismatch between Vite and Express

**What happened:**
The Vite app runs on one port (e.g. 5173) and the API on another (5001). Browser requests would fail with CORS or wrong-origin errors if pointed incorrectly.

**How it was overcome:**
- Enabled `cors()` on Express and added a Vite **proxy**, so the frontend calls `/api/...` and Vite forwards to `http://localhost:5001`.
- Centralised all fetch calls in `src/api.js` and connected Buy/Borrow, Sell/Lend, My Listings, Messages, Transactions, Profile and Admin pages to it.

---

### Problem 3 — Empty database vs. demo-ready UI

**What happened:**
A brand-new database has no listings, so Buy/Borrow and Dashboard looked broken even when the API worked. Real usage data only appears after people use the app.

**How it was overcome:**
- Wrote `server/seed.js` with relevant sample data, first 15 listings and later about 30 verified students and about 70 sale and lend listings, plus loans, reviews, watchlists, notifications, payments and high-risk fraud examples (all marked `isSeed: true`).
- The server seeds automatically when the database is empty; manual re-seed with `npm run seed`. Demo logins for a student and an admin are documented.

---

### Problem 4 — Sign-up, login and session handling in the UI

**What happened:**
With verification and Google Sign-In added on the backend, the UI needed a clear register, OTP and login flow and a way to keep the session and protect pages.

**How it was overcome:**
- Built the Auth page (register, 6-digit OTP, login, Continue with Google) and the Google callback page.
- Added an auth context that stores the token and signed-in user and handles logout, so protected pages only load for verified users.

---

### Problem 5 — Many screens were still static or incomplete

**What happened:**
Messages, notifications, transactions, watchlist and the dashboard needed to reflect live data and the new borrow/lend states (due soon, overdue, extension, return).

**How it was overcome:**
- Built the Messages, Notifications and Transactions ("Loans & payments") pages, favourites (watchlist) support, My Listings actions and the Dashboard on top of the API.
- Showed due-date labels ("Due in 2 days", "1 day overdue") and loan status on the Transactions page.

---

### Problem 6 — AI results and fraud decisions were invisible to users

**What happened:**
The price and fraud models only mattered if sellers, buyers and admins could see and understand their output.

**How it was overcome:**
- Built the **PriceInsight** component: recommended price, fair band, confidence, explanation, a "formula estimate" label when the ML service is down, and live campus comparables when enough similar listings exist.
- Extended the Sell/Lend form with the inputs the model needs (original price, condition, age, brand) and the fraud-warning messages shown after publishing.
- Built the **TrustBadge** component and the **Admin Moderation** page for reviewing held listings.

---

### Problem 7 — Photos, checkout and nearby search needed real UI

**What happened:**
Cloud image upload, payments and optional location sharing existed on the backend but had no user-facing controls.

**How it was overcome:**
- Built the **ImageUploader** (photos upload as soon as they are picked, with status and limits).
- Built the checkout flow with Razorpay and a clearly labelled development mode ("Simulate signed success").
- Added the Profile opt-in for nearby discovery (browser permission), the per-listing "Show in nearby searches" option, and the Buy/Borrow "Nearby only" filter with a radius slider showing results like `~1.2 km away`.

---

### Problem 8 — The project was hard to run, test and explain

**What happened:**
With many moving parts (frontend, API, ML service, payments, storage) a new person could not tell how to start or verify it.

**How it was overcome:**
- Wrote the full **README**: architecture, folder structure, environment variables, database and seed setup, how to run each service, payment and storage guides, API overview, known limitations.
- Added a step-by-step manual test checklist and kept `npm run lint` and `npm run build` passing.

---

## 3. My part of the architecture

| Layer | Responsibility | Owner |
|--------|----------------|-------|
| React (Vite) frontend wiring | Icon hydration, API client, pages and components | **Me** |
| Dev environment (CORS + Vite proxy) | Frontend and backend connectivity | **Me** |
| Seed data (`server/seed.js`) | Demo-ready users, listings, loans, reviews, notifications | **Me** |
| Auth and marketplace UI | Auth page, Messages, Notifications, Transactions, Dashboard | **Me** |
| AI / trust UI | PriceInsight, TrustBadge, Admin Moderation page | **Me** |
| Uploads, checkout, location UI | ImageUploader, payment flow, nearby filter | **Me** |
| Documentation | README, manual test checklist | **Me** |

---

## 4. Reflection

My part of the work was less about database internals and more about making sure the frontend and backend actually talked to each other cleanly, and that the app looked "alive" the moment someone opened it, rather than a blank, broken-looking screen. Fixing the icon-storage mismatch, sorting out CORS and proxy config, writing realistic seed data and then building the interfaces for pricing, fraud review, payments, uploads and location meant the rest of the team's backend and ML work was actually visible, usable and demoable.
