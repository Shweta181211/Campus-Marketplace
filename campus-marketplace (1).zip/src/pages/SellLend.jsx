import { useState, useMemo } from 'react'
import { ShieldCheck, ArrowLeft, PartyPopper } from 'lucide-react'
import ImageUploader from '../components/ImageUploader'
import CategoryDropdown from '../components/CategoryDropdown'
import PriceInsight from '../components/PriceInsight'
import WashiTape from '../components/WashiTape'
import { categories } from '../data/mockData'

const conditions = ['New', 'Like New', 'Good', 'Fair']

export default function SellLend({ onPublish }) {
  const [step, setStep] = useState('form') // form | preview | success
  const [images, setImages] = useState([])
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [category, setCategory] = useState('')
  const [condition, setCondition] = useState('')
  const [listingType, setListingType] = useState('sell') // sell | lend
  const [price, setPrice] = useState('')
  const [lendUnit, setLendUnit] = useState('day')

  const fairRange = useMemo(() => {
    const base = title.length ? 300 + (title.length % 10) * 150 : 500
    return { min: Math.round(base * 0.85), max: Math.round(base * 1.15) }
  }, [title])

  const catObj = categories.find((c) => c.id === category)
  const isFormValid = title && category && condition && price

  const handlePublish = () => {
    setStep('success')
    onPublish?.({
      title, category, condition, listingType, price: Number(price), lendUnit,
      description, images,
    })
  }

  const reset = () => {
    setStep('form'); setImages([]); setTitle(''); setDescription('')
    setCategory(''); setCondition(''); setListingType('sell'); setPrice('')
  }

  if (step === 'success') {
    return (
      <div className="max-w-md mx-auto px-4 py-24 text-center">
        <div className="w-20 h-20 rounded-full bg-moss-bg border-[1.5px] border-moss-ink/40 flex items-center justify-center mx-auto mb-5 animate-[popIn_0.4s_ease]">
          <PartyPopper size={32} className="text-moss-ink" />
        </div>
        <h2 className="font-display font-bold text-xl mb-2">Your listing is now live 🎉</h2>
        <p className="text-sm text-ink-soft mb-6">Buyers and borrowers on campus can now find and message you about it.</p>
        <button onClick={reset} className="bg-ink text-paper rounded-full px-5 py-2.5 text-sm font-medium">
          List another item
        </button>
        <style>{`@keyframes popIn { from { transform: scale(0.5); opacity: 0 } to { transform: scale(1); opacity: 1 } }`}</style>
      </div>
    )
  }

  if (step === 'preview') {
    const Icon = catObj?.icon
    return (
      <div className="max-w-lg mx-auto px-4 md:px-6 py-8">
        <button onClick={() => setStep('form')} className="flex items-center gap-1.5 text-sm text-ink-soft mb-5 hover:text-ink">
          <ArrowLeft size={15} /> Back to edit
        </button>
        <h1 className="font-display font-bold text-2xl mb-5">Your listing</h1>

        <div className="bg-paper-card border-[1.5px] border-ink rounded-md p-4 relative" style={{ transform: 'rotate(-1deg)' }}>
          <WashiTape color={catObj?.tape || 'sky'} rotate={-6} className="-top-2.5 left-8" width={50} />
          {images[0] ? (
            <img src={images[0].url} alt="" className="w-full h-52 object-cover rounded-[3px] border border-ink/70" />
          ) : (
            <div className="w-full h-52 rounded-[3px] border border-ink/70 bg-white flex items-center justify-center">
              {Icon && <Icon size={44} strokeWidth={1.4} className="text-ink-soft" />}
            </div>
          )}
          <h2 className="font-display font-bold text-lg mt-3">{title || 'Untitled item'}</h2>
          <div className="flex gap-2 mt-1.5">
            <span className="text-xs font-mono px-2 py-0.5 rounded-full border border-ink/20 bg-white capitalize">{category}</span>
            <span className="text-xs font-mono px-2 py-0.5 rounded-full border border-ink/20 bg-white">{condition}</span>
          </div>
          <p className="font-mono text-lg font-semibold text-coral-ink mt-2">
            {listingType === 'lend' ? `₹${price || 0}/${lendUnit}` : `₹${price || 0}`}
          </p>
          <p className="text-sm text-ink-soft mt-2">{description || 'No description added.'}</p>
          <p className="text-xs text-ink-soft mt-3 border-t border-line pt-2">Location: approximate campus location, shared only after you accept a request</p>
        </div>

        <div className="flex gap-3 mt-6">
          <button onClick={() => setStep('form')} className="flex-1 border-[1.5px] border-ink rounded-full py-2.5 text-sm font-medium hover:bg-white">
            Back to edit
          </button>
          <button onClick={handlePublish} className="flex-1 bg-ink text-paper rounded-full py-2.5 text-sm font-medium hover:opacity-90">
            Publish listing
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="max-w-lg mx-auto px-4 md:px-6 py-8">
      <h1 className="font-display font-bold text-2xl mb-1">List an item</h1>
      <p className="text-sm text-ink-soft mb-6">Takes about a minute. You can edit anything before it goes live.</p>

      <div className="space-y-6">
        <div>
          <label className="text-xs font-mono uppercase tracking-wide text-ink-soft mb-2 block">Upload product photos</label>
          <ImageUploader images={images} setImages={setImages} />
        </div>

        <div>
          <label className="text-xs font-mono uppercase tracking-wide text-ink-soft mb-1.5 block">Product title</label>
          <input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="e.g. Engineering Mathematics Textbook"
            className="w-full bg-white border-[1.5px] border-ink rounded-md px-3.5 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-tape-yellow"
          />
        </div>

        <div>
          <label className="text-xs font-mono uppercase tracking-wide text-ink-soft mb-1.5 block">Description</label>
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={3}
            placeholder="Condition details, why you're selling, anything a buyer should know..."
            className="w-full bg-white border-[1.5px] border-ink rounded-md px-3.5 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-tape-yellow resize-none"
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="text-xs font-mono uppercase tracking-wide text-ink-soft mb-1.5 block">Category</label>
            <CategoryDropdown value={category} onChange={setCategory} />
          </div>
          <div>
            <label className="text-xs font-mono uppercase tracking-wide text-ink-soft mb-1.5 block">Condition</label>
            <select
              value={condition}
              onChange={(e) => setCondition(e.target.value)}
              className="w-full bg-white border-[1.5px] border-ink rounded-md px-3.5 py-2.5 text-sm focus:outline-none"
            >
              <option value="">Select</option>
              {conditions.map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
        </div>

        <div>
          <label className="text-xs font-mono uppercase tracking-wide text-ink-soft mb-2 block">Listing type</label>
          <div className="inline-flex bg-white border-[1.5px] border-ink rounded-full p-1 w-full">
            {['sell', 'lend'].map((t) => (
              <button
                key={t}
                onClick={() => setListingType(t)}
                className={`flex-1 py-1.5 rounded-full text-sm font-medium capitalize transition-colors ${
                  listingType === t ? 'bg-ink text-paper' : 'text-ink-soft'
                }`}
              >
                {t}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 items-end">
          <div>
            <label className="text-xs font-mono uppercase tracking-wide text-ink-soft mb-1.5 block">
              {listingType === 'sell' ? 'Asking price (₹)' : 'Lending price (₹)'}
            </label>
            <input
              type="number"
              value={price}
              onChange={(e) => setPrice(e.target.value)}
              placeholder="0"
              className="w-full bg-white border-[1.5px] border-ink rounded-md px-3.5 py-2.5 text-sm font-mono focus:outline-none focus:ring-2 focus:ring-tape-yellow"
            />
          </div>
          {listingType === 'lend' && (
            <div>
              <label className="text-xs font-mono uppercase tracking-wide text-ink-soft mb-1.5 block">Per</label>
              <select
                value={lendUnit}
                onChange={(e) => setLendUnit(e.target.value)}
                className="w-full bg-white border-[1.5px] border-ink rounded-md px-3.5 py-2.5 text-sm focus:outline-none"
              >
                <option value="day">day</option>
                <option value="week">week</option>
                <option value="semester">semester</option>
              </select>
            </div>
          )}
        </div>

        {title && category && condition && (
          <PriceInsight fairMin={fairRange.min} fairMax={fairRange.max} price={Number(price) || fairRange.min} />
        )}

        <div className="flex items-center gap-2 text-xs text-moss-ink bg-moss-bg border border-moss-ink/30 rounded-md px-3 py-2.5">
          <ShieldCheck size={15} />
          Listing safety check ✓ — looks good to publish
        </div>

        <button
          disabled={!isFormValid}
          onClick={() => setStep('preview')}
          className="w-full bg-ink text-paper rounded-full py-3 text-sm font-medium disabled:opacity-40 disabled:cursor-not-allowed hover:opacity-90 transition-opacity"
        >
          Preview listing
        </button>
      </div>
    </div>
  )
}
