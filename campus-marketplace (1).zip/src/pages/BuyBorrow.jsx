import { useState, useMemo, useEffect } from 'react'
import { useLocation } from 'react-router-dom'
import { SlidersHorizontal, X } from 'lucide-react'
import CategoryDropdown from '../components/CategoryDropdown'
import FilterPanel from '../components/FilterPanel'
import ProductGrid from '../components/ProductGrid'
import { listings } from '../data/mockData'

export default function BuyBorrow({ search, favorites, onToggleFavorite, onOpenProduct }) {
  const routerLocation = useLocation()
  const [mode, setMode] = useState('buy') // buy | borrow
  const [category, setCategory] = useState('')
  const [showFilters, setShowFilters] = useState(false)
  const [filters, setFilters] = useState({ condition: '', maxPrice: 5000, nearby: false, sort: 'recent' })

  useEffect(() => {
    if (routerLocation.state?.category) setCategory(routerLocation.state.category)
  }, [routerLocation.state])

  const filtered = useMemo(() => {
    let items = listings.filter((l) => (mode === 'buy' ? l.type === 'buy' : l.type === 'lend'))
    if (category) items = items.filter((l) => l.category === category)
    if (search) {
      const q = search.toLowerCase()
      items = items.filter((l) => l.title.toLowerCase().includes(q) || l.category.toLowerCase().includes(q))
    }
    if (filters.condition) items = items.filter((l) => l.condition === filters.condition)
    items = items.filter((l) => l.price <= filters.maxPrice)
    if (filters.nearby) items = items.filter((l) => l.id % 2 === 1)

    if (filters.sort === 'price-asc') items = [...items].sort((a, b) => a.price - b.price)
    else if (filters.sort === 'price-desc') items = [...items].sort((a, b) => b.price - a.price)
    else if (filters.sort === 'nearby') items = [...items].sort((a, b) => a.location.localeCompare(b.location))
    else items = [...items].sort((a, b) => b.id - a.id)

    return items
  }, [mode, category, search, filters])

  return (
    <div className="max-w-6xl mx-auto px-4 md:px-6 py-8">
      <h1 className="font-display font-bold text-2xl mb-1">Buy / Borrow</h1>
      <p className="text-sm text-ink-soft mb-6">{search ? `Results for "${search}"` : 'Find something you need on campus'}</p>

      <div className="flex flex-wrap items-center gap-3 mb-6">
        <div className="inline-flex bg-white border-[1.5px] border-ink rounded-full p-1">
          {['buy', 'borrow'].map((m) => (
            <button
              key={m}
              onClick={() => setMode(m)}
              className={`px-4 py-1.5 rounded-full text-sm font-medium capitalize transition-colors ${
                mode === m ? 'bg-ink text-paper' : 'text-ink-soft hover:text-ink'
              }`}
            >
              {m}
            </button>
          ))}
        </div>

        <CategoryDropdown value={category} onChange={setCategory} />

        <button
          onClick={() => setShowFilters((s) => !s)}
          className="lg:hidden inline-flex items-center gap-2 bg-white border-[1.5px] border-ink rounded-md px-3.5 py-2 text-sm font-medium"
        >
          <SlidersHorizontal size={15} />
          Filters
        </button>

        {category && (
          <button
            onClick={() => setCategory('')}
            className="inline-flex items-center gap-1 text-xs font-mono bg-yellow-bg text-yellow-ink border border-yellow-ink/30 px-2.5 py-1.5 rounded-full"
          >
            {category} <X size={12} />
          </button>
        )}
      </div>

      <div className="grid lg:grid-cols-[220px_1fr] gap-8">
        <div className="hidden lg:block">
          <FilterPanel filters={filters} setFilters={setFilters} />
        </div>

        {showFilters && (
          <div className="lg:hidden mb-2">
            <FilterPanel filters={filters} setFilters={setFilters} />
          </div>
        )}

        <ProductGrid
          items={filtered}
          favorites={favorites}
          onToggleFavorite={onToggleFavorite}
          onOpen={onOpenProduct}
        />
      </div>
    </div>
  )
}
