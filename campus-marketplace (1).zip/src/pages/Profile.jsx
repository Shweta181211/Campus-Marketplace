import { ShieldCheck, Star, ListChecks, Mail } from 'lucide-react'
import Avatar from '../components/Avatar'
import WashiTape from '../components/WashiTape'
import { currentUser, reviews } from '../data/mockData'

export default function Profile() {
  return (
    <div className="max-w-2xl mx-auto px-4 md:px-6 py-8">
      <div className="relative bg-paper-card border-[1.5px] border-ink rounded-md p-6" style={{ transform: 'rotate(-0.5deg)' }}>
        <WashiTape color="yellow" rotate={-6} className="-top-2.5 left-10" width={60} />
        <div className="flex items-center gap-4">
          <Avatar emoji={currentUser.avatar} size="xl" rotate={-3} />
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-display font-bold text-xl">{currentUser.name}</h1>
              {currentUser.verified && <ShieldCheck size={18} className="text-moss-ink" />}
            </div>
            <p className="text-xs text-ink-soft flex items-center gap-1.5 mt-1">
              <Mail size={12} /> {currentUser.email}
            </p>
            <p className="text-xs text-ink-soft mt-0.5">Member since {currentUser.joined}</p>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-3 mt-6">
          <div className="bg-moss-bg border border-moss-ink/30 rounded-md p-3 text-center">
            <p className="font-mono font-semibold text-moss-ink">{currentUser.trust.toFixed(1)}</p>
            <p className="text-[10.5px] text-moss-ink/80 mt-0.5">Trust score</p>
          </div>
          <div className="bg-yellow-bg border border-yellow-ink/30 rounded-md p-3 text-center">
            <p className="font-mono font-semibold text-yellow-ink">{currentUser.rating} <Star size={11} className="inline fill-yellow-ink -mt-0.5" /></p>
            <p className="text-[10.5px] text-yellow-ink/80 mt-0.5">{currentUser.reviewCount} reviews</p>
          </div>
          <div className="bg-sky-bg border border-sky-ink/30 rounded-md p-3 text-center">
            <p className="font-mono font-semibold text-sky-ink">{currentUser.listingsCount}</p>
            <p className="text-[10.5px] text-sky-ink/80 mt-0.5">Listings</p>
          </div>
        </div>
      </div>

      <div className="mt-8">
        <div className="flex items-center gap-2 mb-3">
          <ListChecks size={16} />
          <h2 className="font-display font-semibold text-base">Recent reviews</h2>
        </div>
        <div className="space-y-3">
          {reviews.map((r) => (
            <div key={r.id} className="bg-white border border-ink/15 rounded-md p-3.5 flex gap-3">
              <div className="w-9 h-9 rounded-md bg-paper-card border border-ink flex items-center justify-center text-base shrink-0">
                {r.avatar}
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <p className="text-sm font-medium">{r.from}</p>
                  <div className="flex text-yellow-ink">
                    {Array.from({ length: r.rating }).map((_, i) => <Star key={i} size={10} className="fill-yellow-ink" />)}
                  </div>
                </div>
                <p className="text-xs text-ink-soft mt-0.5">{r.text}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
