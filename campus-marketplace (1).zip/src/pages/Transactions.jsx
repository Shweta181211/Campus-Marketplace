import { Receipt, ArrowDownLeft, ArrowUpRight } from 'lucide-react'

const txns = [
  { item: 'Scientific Calculator', with: 'Priya Nair', amount: 650, type: 'bought', date: 'Aug 14' },
  { item: 'Lab Coat', with: 'Ishaan Kapoor', amount: 250, type: 'bought', date: 'Aug 9' },
  { item: 'Study Table', with: 'Meera Iyer', amount: 800, type: 'sold', date: 'Jul 28' },
]

export default function Transactions() {
  return (
    <div className="max-w-2xl mx-auto px-4 md:px-6 py-8">
      <h1 className="font-display font-bold text-2xl mb-1">Transactions</h1>
      <p className="text-sm text-ink-soft mb-6">A record of what you've bought, sold, borrowed and lent</p>

      <div className="bg-paper-card border-[1.5px] border-ink rounded-md divide-y divide-line overflow-hidden">
        {txns.map((t) => (
          <div key={t.item} className="flex items-center gap-3 p-4">
            <div className={`w-9 h-9 rounded-full flex items-center justify-center shrink-0 ${t.type === 'bought' ? 'bg-coral-bg' : 'bg-moss-bg'}`}>
              {t.type === 'bought'
                ? <ArrowDownLeft size={16} className="text-coral-ink" />
                : <ArrowUpRight size={16} className="text-moss-ink" />}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate">{t.item}</p>
              <p className="text-xs text-ink-soft">{t.type === 'bought' ? 'Bought from' : 'Sold to'} {t.with} · {t.date}</p>
            </div>
            <span className="font-mono text-sm font-semibold shrink-0">₹{t.amount}</span>
          </div>
        ))}
      </div>

      <div className="flex flex-col items-center text-center text-ink-soft mt-10">
        <Receipt size={28} className="mb-2" />
        <p className="text-sm">Live transaction tracking is coming soon — this is a preview layout.</p>
      </div>
    </div>
  )
}
