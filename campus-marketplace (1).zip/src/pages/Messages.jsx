import { MessageCircle } from 'lucide-react'
import { avatars } from '../data/mockData'

const threads = [
  { name: 'Aditi Rao', avatar: avatars[0], preview: 'Is the textbook still available?', time: '2m', unread: true, item: 'Engineering Mathematics Textbook' },
  { name: 'Rohan Mehta', avatar: avatars[1], preview: 'Can we meet near Block C at 5?', time: '1h', unread: false, item: 'Mountain Bike' },
  { name: 'Karan Suri', avatar: avatars[3], preview: 'Thanks, works great!', time: '1d', unread: false, item: 'Mini Fridge' },
]

export default function Messages() {
  return (
    <div className="max-w-2xl mx-auto px-4 md:px-6 py-8">
      <h1 className="font-display font-bold text-2xl mb-1">Messages</h1>
      <p className="text-sm text-ink-soft mb-6">Chats with buyers, sellers and borrowers on campus</p>

      <div className="bg-paper-card border-[1.5px] border-ink rounded-md divide-y divide-line overflow-hidden">
        {threads.map((t) => (
          <button key={t.name} className="w-full flex items-center gap-3 p-4 text-left hover:bg-white transition-colors">
            <div className="w-10 h-10 rounded-md bg-white border-[1.5px] border-ink flex items-center justify-center text-lg shrink-0" style={{ transform: 'rotate(-3deg)' }}>
              {t.avatar}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between">
                <p className="text-sm font-medium">{t.name}</p>
                <span className="text-[11px] text-ink-soft">{t.time}</span>
              </div>
              <p className="text-xs text-ink-soft truncate">{t.preview}</p>
              <p className="text-[10.5px] text-ink-soft/70 mt-0.5">re: {t.item}</p>
            </div>
            {t.unread && <span className="w-2 h-2 rounded-full bg-tape-coral shrink-0" />}
          </button>
        ))}
      </div>

      <div className="flex flex-col items-center text-center text-ink-soft mt-10">
        <MessageCircle size={28} className="mb-2" />
        <p className="text-sm">Full chat is coming soon — this is a preview of the messages layout.</p>
      </div>
    </div>
  )
}
