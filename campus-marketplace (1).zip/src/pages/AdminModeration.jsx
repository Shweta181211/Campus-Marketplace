import { ShieldAlert } from 'lucide-react'
import { moderationQueue } from '../data/mockData'

const riskStyles = {
  Low: 'bg-moss-bg text-moss-ink border-moss-ink/30',
  Medium: 'bg-yellow-bg text-yellow-ink border-yellow-ink/30',
  High: 'bg-coral-bg text-coral-ink border-coral-ink/30',
}

export default function AdminModeration() {
  return (
    <div className="max-w-3xl mx-auto px-4 md:px-6 py-8">
      <div className="flex items-center gap-2 mb-1">
        <ShieldAlert size={20} />
        <h1 className="font-display font-bold text-2xl">Moderation queue</h1>
      </div>
      <p className="text-sm text-ink-soft mb-6">Listings flagged by the fraud model for human review. Nothing here is auto-removed.</p>

      <div className="space-y-3">
        {moderationQueue.map((m) => (
          <div key={m.id} className="bg-paper-card border-[1.5px] border-ink rounded-md p-4">
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="font-medium text-sm">{m.listing}</p>
                <p className="text-xs text-ink-soft mt-0.5">Seller: {m.seller}</p>
              </div>
              <span className={`text-xs font-mono font-medium px-2.5 py-1 rounded-full border shrink-0 ${riskStyles[m.risk]}`}>
                {m.risk} risk
              </span>
            </div>
            <p className="text-xs text-ink-soft mt-3 leading-relaxed">{m.reason}</p>
            <div className="flex gap-2 mt-3">
              <button className="text-xs font-medium border-[1.5px] border-ink rounded-full px-3.5 py-1.5 hover:bg-white">
                Review listing
              </button>
              <button className="text-xs font-medium text-ink-soft hover:text-ink px-3.5 py-1.5">
                Dismiss
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
