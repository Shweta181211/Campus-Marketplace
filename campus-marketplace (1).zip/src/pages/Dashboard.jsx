import { useNavigate } from 'react-router-dom'
import { ShoppingBag, PackagePlus, MapPin, TrendingUp } from 'lucide-react'
import WashiTape from '../components/WashiTape'
import { categories, listings } from '../data/mockData'

const bgMap = { sky: 'bg-sky-bg', coral: 'bg-coral-bg', yellow: 'bg-yellow-bg', moss: 'bg-moss-bg' }

export default function Dashboard({ favorites, onToggleFavorite, onOpenProduct }) {
  const navigate = useNavigate()
  const recent = listings.slice(0, 8)

  return (
    <div className="max-w-6xl mx-auto px-4 md:px-6 py-8 space-y-12">
      <div>
        <p className="font-mono text-xs uppercase tracking-wider text-ink-soft mb-1">Good to see you, Riya</p>
        <h1 className="font-display font-bold text-2xl md:text-3xl">What are you up to today?</h1>
      </div>

      <div className="grid sm:grid-cols-2 gap-8 md:gap-12 pt-2">
        <button
          onClick={() => navigate('/buy-borrow')}
          className="group relative bg-paper-card border-[1.5px] border-ink rounded-md p-6 text-left transition-transform duration-200 hover:-translate-y-1"
          style={{ transform: 'rotate(-1.5deg)' }}
        >
          <WashiTape color="sky" rotate={-8} className="-top-3 left-10" width={64} />
          <div className="w-14 h-14 rounded-md bg-sky-bg border border-ink/70 flex items-center justify-center mb-4">
            <ShoppingBag size={26} className="text-sky-ink" strokeWidth={1.7} />
          </div>
          <h2 className="font-display font-bold text-xl mb-1">Buy / Borrow</h2>
          <p className="text-sm text-ink-soft mb-5">Find something you need on campus</p>
          <span className="inline-block font-mono text-xs bg-ink text-paper px-3.5 py-2 rounded-full group-hover:opacity-90">
            browse listings →
          </span>
        </button>

        <button
          onClick={() => navigate('/sell-lend')}
          className="group relative bg-paper-card border-[1.5px] border-ink rounded-md p-6 text-left transition-transform duration-200 hover:-translate-y-1"
          style={{ transform: 'rotate(1.5deg)' }}
        >
          <WashiTape color="coral" rotate={8} className="-top-3 right-10" width={64} />
          <div className="w-14 h-14 rounded-md bg-coral-bg border border-ink/70 flex items-center justify-center mb-4">
            <PackagePlus size={26} className="text-coral-ink" strokeWidth={1.7} />
          </div>
          <h2 className="font-display font-bold text-xl mb-1">Sell / Lend</h2>
          <p className="text-sm text-ink-soft mb-5">List something you no longer need</p>
          <span className="inline-block font-mono text-xs bg-ink text-paper px-3.5 py-2 rounded-full group-hover:opacity-90">
            list an item →
          </span>
        </button>
      </div>

      <div>
        <h3 className="font-display font-semibold text-base mb-4">Popular categories</h3>
        <div className="flex gap-3 overflow-x-auto no-scrollbar pb-2">
          {categories.map((c) => (
            <button
              key={c.id}
              onClick={() => navigate('/buy-borrow', { state: { category: c.id } })}
              className="shrink-0 flex flex-col items-center gap-2 group"
            >
              <div className={`w-14 h-14 rounded-full border-[1.5px] border-ink flex items-center justify-center bg-white group-hover:-translate-y-0.5 transition-transform`}>
                <c.icon size={22} strokeWidth={1.7} />
              </div>
              <span className="text-xs font-medium text-ink-soft">{c.label}</span>
            </button>
          ))}
        </div>
      </div>

      <div>
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-display font-semibold text-base">Recently listed</h3>
          <button onClick={() => navigate('/buy-borrow')} className="text-xs font-mono text-ink-soft hover:text-ink underline underline-offset-2">
            view all
          </button>
        </div>
        <div className="flex gap-4 overflow-x-auto no-scrollbar pb-3">
          {recent.map((item, i) => (
            <button
              key={item.id}
              onClick={() => onOpenProduct(item)}
              className="shrink-0 w-40 bg-paper-card border-[1.5px] border-ink rounded-sm p-2.5"
              style={{ transform: `rotate(${(i % 2 === 0 ? -1 : 1) * 1.5}deg)` }}
            >
              <div className={`h-20 rounded-[3px] border border-ink/60 flex items-center justify-center ${bgMap[item.bg]}`}>
                <item.icon size={26} strokeWidth={1.6} />
              </div>
              <p className="text-xs font-medium mt-2 text-left truncate">{item.title}</p>
              <p className="font-mono text-xs text-coral-ink text-left mt-0.5">
                {item.type === 'lend' ? `₹${item.price}/${item.lendUnit}` : `₹${item.price}`}
              </p>
            </button>
          ))}
        </div>
      </div>

      <div>
        <div className="flex items-center gap-2 mb-4">
          <MapPin size={16} />
          <h3 className="font-display font-semibold text-base">Nearby on campus</h3>
        </div>
        <div className="grid sm:grid-cols-3 gap-4">
          {['Block C, near mess', 'Hostel D parking', 'Block A'].map((loc, i) => (
            <div key={loc} className="bg-white border border-ink/20 rounded-md p-4 flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-moss-bg flex items-center justify-center shrink-0">
                <TrendingUp size={16} className="text-moss-ink" />
              </div>
              <div>
                <p className="text-sm font-medium">{loc}</p>
                <p className="text-xs text-ink-soft">{2 + i} listings within 200m</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
