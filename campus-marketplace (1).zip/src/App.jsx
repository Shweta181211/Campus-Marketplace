import { useState } from 'react'
import { Routes, Route, useLocation } from 'react-router-dom'
import Navbar from './components/Navbar'
import Sidebar from './components/Sidebar'
import Modal from './components/Modal'
import Toast from './components/Toast'
import ProductDetails from './components/ProductDetails'
import Dashboard from './pages/Dashboard'
import BuyBorrow from './pages/BuyBorrow'
import SellLend from './pages/SellLend'
import MyListings from './pages/MyListings'
import Messages from './pages/Messages'
import Transactions from './pages/Transactions'
import Profile from './pages/Profile'
import AdminModeration from './pages/AdminModeration'

export default function App() {
  const location = useLocation()
  const [search, setSearch] = useState('')
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [favorites, setFavorites] = useState([3, 7])
  const [activeProduct, setActiveProduct] = useState(null)
  const [toast, setToast] = useState({ show: false, message: '' })
  const [myListings, setMyListings] = useState([])

  const toggleFavorite = (id) => {
    setFavorites((favs) => favs.includes(id) ? favs.filter((f) => f !== id) : [...favs, id])
  }

  const showToast = (message) => setToast({ show: true, message })

  const handleProductAction = (kind) => {
    setActiveProduct(null)
    if (kind === 'chat') showToast('Opening chat with seller...')
    else showToast(activeProduct?.type === 'lend' ? 'Borrow request sent 📨' : 'Purchase request sent 📨')
  }

  const handlePublish = (listing) => {
    setMyListings((l) => [{ ...listing }, ...l])
  }

  return (
    <div className="min-h-screen">
      <Navbar search={search} setSearch={setSearch} onMenuClick={() => setSidebarOpen(true)} />
      <div className="md:flex">
        <Sidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />
        <main className="flex-1 min-w-0">
          <Routes location={location} key={location.pathname}>
            <Route path="/" element={<Dashboard favorites={favorites} onToggleFavorite={toggleFavorite} onOpenProduct={setActiveProduct} />} />
            <Route path="/buy-borrow" element={<BuyBorrow search={search} favorites={favorites} onToggleFavorite={toggleFavorite} onOpenProduct={setActiveProduct} />} />
            <Route path="/sell-lend" element={<SellLend onPublish={handlePublish} />} />
            <Route path="/my-listings" element={<MyListings myListings={myListings} onOpenProduct={setActiveProduct} />} />
            <Route path="/messages" element={<Messages />} />
            <Route path="/transactions" element={<Transactions />} />
            <Route path="/profile" element={<Profile />} />
            <Route path="/admin" element={<AdminModeration />} />
          </Routes>
        </main>
      </div>

      <Modal open={!!activeProduct} onClose={() => setActiveProduct(null)} wide>
        {activeProduct && (
          <ProductDetails
            item={activeProduct}
            actionLabel={activeProduct.type === 'lend' ? 'Request to borrow' : 'Buy now'}
            onRequestAction={handleProductAction}
          />
        )}
      </Modal>

      <Toast show={toast.show} message={toast.message} onClose={() => setToast({ show: false, message: '' })} />
    </div>
  )
}
