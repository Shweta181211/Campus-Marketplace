import { ShieldCheck, Star } from 'lucide-react'

export default function TrustBadge({ trust, verified, compact = false }) {
  if (compact) {
    return (
      <span className="inline-flex items-center gap-1 text-[11px] font-mono font-medium text-moss-ink bg-moss-bg border border-moss-ink/30 px-2 py-0.5 rounded-full">
        <Star size={11} className="fill-moss-ink" />
        {trust.toFixed(1)}
      </span>
    )
  }
  return (
    <div className="inline-flex items-center gap-1.5 text-xs font-mono font-medium text-moss-ink bg-moss-bg border border-moss-ink/30 px-2.5 py-1 rounded-full">
      {verified ? <ShieldCheck size={13} /> : <Star size={13} className="fill-moss-ink" />}
      <span>{trust.toFixed(1)} trust score</span>
      {verified && <span className="opacity-70">· verified</span>}
    </div>
  )
}
