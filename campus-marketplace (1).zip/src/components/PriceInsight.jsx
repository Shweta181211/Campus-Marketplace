import { useState } from 'react'
import { Sparkles, ChevronDown } from 'lucide-react'

export default function PriceInsight({ fairMin, fairMax, price }) {
  const [showWhy, setShowWhy] = useState(false)

  let status = 'Fairly priced'
  let statusColor = 'moss'
  if (price > fairMax * 1.1) { status = 'Priced above market'; statusColor = 'coral' }
  else if (price < fairMin * 0.85) { status = 'Priced below market'; statusColor = 'sky' }

  const colorClasses = {
    moss: 'bg-moss-bg text-moss-ink border-moss-ink/30',
    coral: 'bg-coral-bg text-coral-ink border-coral-ink/30',
    sky: 'bg-sky-bg text-sky-ink border-sky-ink/30',
  }

  const range = fairMax - fairMin
  const clamped = Math.min(Math.max(price, fairMin - range * 0.3), fairMax + range * 0.3)
  const pct = ((clamped - (fairMin - range * 0.3)) / (range * 1.6)) * 100

  return (
    <div className="bg-yellow-bg border-[1.5px] border-yellow-ink/40 rounded-md p-4">
      <div className="flex items-center gap-2 font-display font-semibold text-sm text-yellow-ink mb-3">
        <Sparkles size={15} />
        AI price insight
      </div>

      <div className="flex items-center justify-between text-xs font-mono mb-1.5">
        <span className="text-ink-soft">₹{fairMin}</span>
        <span className="text-ink-soft">₹{fairMax}</span>
      </div>
      <div className="relative h-2.5 bg-white rounded-full border border-ink/15 mb-1">
        <div
          className="absolute inset-y-0 bg-tape-moss/50 rounded-full"
          style={{ left: '15%', right: '15%' }}
        />
        <div
          className="absolute -top-1 w-4 h-4 rounded-full bg-ink border-2 border-white shadow"
          style={{ left: `calc(${pct}% - 8px)` }}
        />
      </div>
      <p className="text-[11px] text-ink-soft mb-3">Estimated fair range based on similar campus listings</p>

      <div className="flex items-center justify-between">
        <span className={`text-xs font-mono font-medium px-2.5 py-1 rounded-full border ${colorClasses[statusColor]}`}>
          {status === 'Fairly priced' ? '✓ ' : ''}{status}
        </span>
        <span className="text-xs text-ink-soft font-mono">confidence 78%</span>
      </div>

      <button
        onClick={() => setShowWhy((s) => !s)}
        className="flex items-center gap-1 text-xs font-medium text-yellow-ink mt-3 hover:underline"
      >
        Why? <ChevronDown size={13} className={`transition-transform ${showWhy ? 'rotate-180' : ''}`} />
      </button>
      {showWhy && (
        <p className="text-xs text-ink-soft mt-2 leading-relaxed">
          This estimate compares your item's category, condition and recent campus listings of similar
          products. It's a guide, not a guarantee — final pricing is always your call.
        </p>
      )}
    </div>
  )
}
